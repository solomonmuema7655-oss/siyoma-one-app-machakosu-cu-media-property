const state={queue:[],current:-1,blocks:[],selectedBible:null};
const $=id=>document.getElementById(id);
function showPanel(name){document.querySelectorAll('.panel').forEach(x=>x.classList.add('hidden'));$('panel-'+name).classList.remove('hidden');document.querySelectorAll('.nav').forEach(x=>x.classList.toggle('active',x.dataset.panel===name))}
document.querySelectorAll('.nav').forEach(b=>b.onclick=()=>showPanel(b.dataset.panel));
function addTextItem(){let title=$('textTitle').value.trim(),body=$('textBody').value.trim();if(!body)return;state.queue.push({type:'text',title,body});renderQueue();$('textTitle').value='';$('textBody').value='';}
function projectText(){let body=$('textBody').value.trim();if(body)renderProjection({type:'text',title:$('textTitle').value,body})}
function autoSplitLyrics(){let t=$('lyricsInput').value.trim();if(!t)return;let lines=t.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);state.blocks=[];let buf=[];for(const line of lines){buf.push(line);if(buf.length>=2||/[.!?;,:]$/.test(line)){state.blocks.push(buf.join('\n'));buf=[]}}if(buf.length)state.blocks.push(buf.join('\n'));renderBlocks()}
function renderBlocks(){let el=$('blocks');el.innerHTML='';state.blocks.forEach((b,i)=>{let d=document.createElement('div');d.className='block';d.innerHTML=`<b>BLOCK ${i+1}</b><textarea rows="3"></textarea><button>PROJECT</button>`;d.querySelector('textarea').value=b;d.querySelector('button').onclick=()=>renderProjection({type:'text',title:$('songTitle').value,body:d.querySelector('textarea').value});el.appendChild(d)})}
function clearBlocks(){state.blocks=[];renderBlocks()}
function addLyricsItem(){if(!state.blocks.length)autoSplitLyrics();if(state.blocks.length){state.queue.push({type:'lyrics',title:$('songTitle').value,blocks:[...state.blocks]});renderQueue()}}
function searchBible(){let ref=$('bibleRef').value.trim();if(!ref)return;let versions=['KJV','NIV','ESV','NLT','NKJV'];$('bibleResults').innerHTML=versions.map((v,i)=>`<div class="block"><label><input type="checkbox" ${i<3?'checked':''} data-version="${v}"> <b>${v}</b></label><div id="b-${v}">Content will be supplied by the configured Bible provider for <b>${ref}</b>.</div></div>`).join('');state.selectedBible=ref}
function projectBible(){let ref=state.selectedBible||$('bibleRef').value||'Bible Reference';let vs=[...document.querySelectorAll('#bibleResults input:checked')].map(x=>x.dataset.version);if(!vs.length)return;renderProjection({type:'text',title:ref,body:vs.join('  |  ')+'\n\nConnect/configure the licensed Bible provider to retrieve the selected translations.'})}
function loadVideo(){let f=$('videoFile').files[0];if(f){let url=URL.createObjectURL(f);renderProjection({type:'video',url})}else if($('videoUrl').value.trim()){renderProjection({type:'video',url:$('videoUrl').value.trim()})}}
function addVideoItem(){let f=$('videoFile').files[0];if(!f&&!$('videoUrl').value.trim())return;let url=f?URL.createObjectURL(f):$('videoUrl').value.trim();state.queue.push({type:'video',url,title:f?f.name:'Online video'});renderQueue()}
function loadImage(){let f=$('imageFile').files[0];if(f){renderProjection({type:'image',url:URL.createObjectURL(f)})}else if($('imageUrl').value.trim())renderProjection({type:'image',url:$('imageUrl').value.trim()})}
function addImageItem(){let f=$('imageFile').files[0];if(!f&&!$('imageUrl').value.trim())return;let url=f?URL.createObjectURL(f):$('imageUrl').value.trim();state.queue.push({type:'image',url,title:f?f.name:'Online image'});renderQueue()}
function renderProjection(item){let html='';if(item.type==='image')html=`<img src="${item.url}">`;else if(item.type==='video')html=`<video src="${item.url}" controls autoplay></video>`;else html=`<div><h2>${escapeHtml(item.title||'')}</h2><div>${escapeHtml(item.body||'').replace(/\n/g,'<br>')}</div></div>`;$('screenContent').innerHTML=html; $('projectionContent').innerHTML=html}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
function renderQueue(){let q=$('queue');q.innerHTML=state.queue.length?state.queue.map((x,i)=>`<div class="queue-item"><b>${i+1}.</b><span>${escapeHtml(x.title||x.type)}</span><button onclick="goItem(${i})">PROJECT</button></div>`).join(''):'<p class="hint">No service items yet.</p>'}
function goItem(i){state.current=i;let x=state.queue[i];if(x.type==='lyrics'){let b=x.blocks[0]||'';renderProjection({type:'text',title:x.title,body:b})}else renderProjection(x)}
function nextItem(){if(!state.queue.length)return;state.current=Math.min(state.current+1,state.queue.length-1);goItem(state.current)}
function prevItem(){if(!state.queue.length)return;state.current=Math.max(state.current-1,0);goItem(state.current)}
function clearProjection(){$('screenContent').textContent='Projection cleared';$('projectionContent').textContent='Projection cleared'}
function toggleProjection(){$('projection').classList.remove('hidden');if(document.documentElement.requestFullscreen)document.documentElement.requestFullscreen().catch(()=>{})}
function closeProjection(){$('projection').classList.add('hidden');if(document.fullscreenElement)document.exitFullscreen().catch(()=>{})}
function saveService(){localStorage.setItem('siyoma_cu_service',JSON.stringify(state.queue));alert('Service saved on this device.')}
function clearService(){state.queue=[];state.current=-1;renderQueue()}
$('unlockBtn').onclick=()=>{if($('siPassword').value==='239358'){localStorage.setItem('siyoma_unlocked','1');$('lock').classList.add('hidden')}else $('lockMsg').textContent='Incorrect SIYOMA PASSWORD.'};
$('forgotBtn').onclick=()=>{let p=prompt('Enter SIYOMA PASSWORD to reset the app password.');if(p==='239358'){localStorage.removeItem('siyoma_unlocked');alert('Recovery verified. Enter the app again.')}else alert('Recovery verification failed.')};
$('liveBtn').onclick=toggleProjection;$('prepBtn').onclick=()=>showPanel('service');$('settingsBtn').onclick=()=>alert('Settings module reserved for the next build: password change, Bible provider/API configuration, projection preferences and service backup.');
if(localStorage.getItem('siyoma_unlocked')==='1')$('lock').classList.add('hidden');
try{let saved=JSON.parse(localStorage.getItem('siyoma_cu_service')||'[]');state.queue=saved;renderQueue()}catch(e){}

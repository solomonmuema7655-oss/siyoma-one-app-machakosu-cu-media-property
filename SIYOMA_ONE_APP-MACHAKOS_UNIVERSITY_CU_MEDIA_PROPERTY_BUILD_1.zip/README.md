# SIYOMA ONE APP-MACHAKOS UNIVERSITY CU MEDIA PROPERTY

Local-first CU media projection application prototype.

## Included
- Responsive browser version for laptop/phone
- Android WebView project for APK building
- SIYOMA PASSWORD first-access gate (prototype)
- Text/theme/presenter projection
- Lyrics block splitting and manual editing
- Bible multi-version UI architecture (provider/licensing configuration still required)
- Local/URL video and image projection
- Service queue and local save
- Fullscreen projection mode
- Android screen-keep-on behavior

## Projection
Connect the phone/laptop to a compatible external display/projector using the device's supported HDMI/USB-C/display adapter/cable. Start FULLSCREEN / PROJECT mode. Actual external-display support depends on the phone/laptop hardware and operating system.

## Important
The Bible provider is intentionally not hard-coded with copyrighted translations. Before production use, configure a licensed/public-domain/Creative Commons Bible source and its permitted offline/caching rules.

This is Build 1 (functional foundation/prototype), not a final production release.
